import React from "react";
import project1 from "@/public/1.jpg";
import project2 from "@/public/2.jpg";
import project3 from "@/public/3.jpg";
import project4 from "@/public/4.jpg";
import project5 from "@/public/5.jpg";
import ProjectCard from "./ProjectCard";

const ProjectList = [
  {
    id: 1,
    image: project1,
    name: "B1: Revegetación de ejes verdes",
    projectStats: "2025",
    address: "Calle Obispo Rafael Torija, 13004 - Ciudad Real",
  },
  {
    id: 5,
    image: project2,
    name: "B4: Renaturalización del espacio de los Silos",
    projectStats: "2027",
    address: "Avda. Valdepeñas, 13004 - Ciudad Real",
  },
  {
    id: 3,
    image: project3,
    name: "B3.2: Eje verde Leopoldo Calvo Sotelo",
    projectStats: "2026",
    address: "Avda. Calvo Sotelo, 13004 - Ciudad Real",
  },
  {
    id: 4,
    image: project4,
    name: "B7.1: Intinerario histórico Calatrava la Vieja (UCLM)",
    projectStats: "2027",
    address: "Calle Altagrafcia, 50, 13004 - Ciudad Real",
  },
  {
    id: 2,
    image: project5,
    name: "B2: Renaturalización del aparacmiento Gasset",
    projectStats: "2030",
    address: "Parque Gasset, 13004 - Ciudad Real",
  },
];

interface PropertiesDisplayProps {
  hoveredMarkerId: number | null;
}

const PropertiesDisplay = ({ hoveredMarkerId }: PropertiesDisplayProps) => {
  return (
    <div className="grid grid-cols-1 w-[500px] gap-3 overflow-auto px-2">
      {ProjectList.map((project) => (
        <ProjectCard
          key={project.id}
          id={project.id}
          image={project.image}
          name={project.name}
          projectStats={project.projectStats}
          address={project.address}
          highlighted={hoveredMarkerId === project.id}
        />
      ))}
    </div>
  );
};

export default PropertiesDisplay;
