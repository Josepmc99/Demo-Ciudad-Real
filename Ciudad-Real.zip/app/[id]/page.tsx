"use client";

import React from "react";
import PropertyDetail from "@/components/PropertyDetail";

import ProjectList from "@/data/projects";

const ProjectPage = () => {
  return (
    <div className="container mx-auto p-8">
      {ProjectList.map((project) => (
        <PropertyDetail key={project.id} project={project} />
      ))}
    </div>
  );
};

export default ProjectPage;
